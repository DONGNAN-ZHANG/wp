<header class="header">
        <div class="header-text">
            <h1>Pizza workshop</h1>
        </div>
        <div class="header-color">
            <div class="header-color-green"></div>
            <div class="header-color-white"></div>
            <div class="header-color-red"></div>
        </div>
</header>