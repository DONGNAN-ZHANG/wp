<nav class="navbar">
        <div class="container">
            <ul class="nav">
                <li class="nav-item">
                    <a href="./index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a href="./products.php">Products</a>
                </li>
                <li class="nav-item">
                    <a href="">Gallary</a>
                </li>
                <li class="nav-item">
                    <a href="">About</a>
                </li>
                <li class="nav-item">
                    <a href="">Contact</a>
                </li>
                <li class="nav-item">
                    <a href="./login.php">Login</a>
                </li>
                <li class="nav-item">
                    <a href="./cart.php">Cart</a>
                </li>
            </ul>
        </div>
    </nav>